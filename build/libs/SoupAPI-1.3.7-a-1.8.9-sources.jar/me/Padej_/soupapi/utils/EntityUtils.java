package me.Padej_.soupapi.utils;

import me.Padej_.soupapi.SoupAPI;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.potion.Potion;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.MovingObjectPosition;

import static me.Padej_.soupapi.config.ConfigurableModule.mc;

public class EntityUtils {
    private static Entity targetEntity;
    private static EntityLivingBase lastHitEntity;

    public static void updateEntities(Minecraft client) {
        if (client.field_71439_g == null) return;

        MovingObjectPosition hitResult = client.field_71476_x;
        if (hitResult != null && hitResult.field_72313_a == MovingObjectPosition.MovingObjectType.ENTITY && hitResult.field_72308_g != null) {
            Entity checkedEntity = hitResult.field_72308_g;
            if (!isFriend(checkedEntity) && !isSpectator(checkedEntity)) {
                targetEntity = checkedEntity;
            } else {
                targetEntity = null;
            }
        } else {
            targetEntity = null;
        }
    }

    public static boolean isCrit() {
        EntityPlayer player = mc.field_71439_g;
        if (player == null) return false;
        // 1.9 introduced the attack cooldown; in 1.8.9 every swing is at full strength, so the
        // cooldown term of the 1.21.4 check has no counterpart and is dropped.
        return player.field_70143_R > 0.0F &&
                !player.field_70122_E &&
                !player.func_70617_f_() &&
                !player.func_70090_H() &&
                !player.func_70644_a(Potion.field_76440_q) &&
                !player.func_70115_ae() &&
                !player.func_70051_ag();
    }

    /**
     * 1.8.9 declares {@code isSpectator()} on {@link EntityPlayer} rather than {@link Entity}, so
     * non-players are simply never spectators.
     */
    public static boolean isSpectator(Entity entity) {
        return entity instanceof EntityPlayer && ((EntityPlayer) entity).func_175149_v();
    }

    public static boolean isFriend(Entity entity) {
        String entityName = entity.func_70005_c_();
        if (entityName == null) return false;
        for (String friend : SoupAPI.configHolder.get().friends) {
            if (friend.equalsIgnoreCase(entityName)) {
                return true;
            }
        }
        return false;
    }

    public static boolean isFriend(String name) {
        for (String friend : SoupAPI.configHolder.get().friends) {
            if (friend.equalsIgnoreCase(name)) {
                return true;
            }
        }
        return false;
    }

    public static Entity getTargetEntity() {
        return targetEntity;
    }

    public static EntityLivingBase getLastHitEntity() {
        return lastHitEntity;
    }

    public static void clearLastHitEntity() {
        lastHitEntity = null;
    }
}


