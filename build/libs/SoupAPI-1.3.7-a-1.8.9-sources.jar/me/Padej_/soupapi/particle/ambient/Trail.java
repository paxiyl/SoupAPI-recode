package me.Padej_.soupapi.particle.ambient;

import me.Padej_.soupapi.modules.AmbientParticle;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Vec3;

import java.awt.*;

import static me.Padej_.soupapi.config.ConfigurableModule.CONFIG;

public class Trail {
    private static Minecraft mc = Minecraft.func_71410_x();
    private final Vec3 from;
    private final Vec3 to;
    private final Color color;
    private int ticks, prevTicks;

    public Trail(Vec3 from, Vec3 to, Color color) {
        this.from = from;
        this.to = to;
        this.ticks = AmbientParticle.trailLenght.getValue().intValue();
        this.color = color;
    }

    public Vec3 interpolate(float pt) {
        Vec3 cameraPos = new net.minecraft.util.Vec3(mc.func_175598_ae().field_78730_l, mc.func_175598_ae().field_78731_m, mc.func_175598_ae().field_78728_n);
        double x = from.field_72450_a + ((to.field_72450_a - from.field_72450_a) * pt) - cameraPos.field_72450_a;
        double y = from.field_72448_b + ((to.field_72448_b - from.field_72448_b) * pt) - cameraPos.field_72448_b;
        double z = from.field_72449_c + ((to.field_72449_c - from.field_72449_c) * pt) - cameraPos.field_72449_c;
        return new Vec3(x, y, z);
    }

    public double animation(float pt) {
        return (this.prevTicks + (this.ticks - this.prevTicks) * pt) / 10.;
    }

    public boolean update() {
        this.prevTicks = this.ticks;
        return this.ticks-- <= 0;
    }

    public Color color() {
        return color;
    }
}
