package me.Padej_.soupapi.screen;

import me.Padej_.soupapi.compat.Texts;

import me.Padej_.soupapi.config.ConfigManager;
import me.Padej_.soupapi.modules.Capes;
import net.minecraft.client.Minecraft;
import me.Padej_.soupapi.compat.DrawContext;
import me.Padej_.soupapi.compat.SoupScreen;
import me.Padej_.soupapi.compat.RenderLayer;
import net.minecraft.util.IChatComponent;
import net.minecraft.util.ResourceLocation;

import static me.Padej_.soupapi.config.ConfigurableModule.CONFIG;
import static me.Padej_.soupapi.config.ConfigurableModule.saveConfig;

public class CapeSelectScreen extends SoupScreen {
    private static final int TEXTURE_RENDER_WIDTH = 20;
    private static final int TEXTURE_RENDER_HEIGHT = 32;
    private static final int PADDING = 8;
    private static final int BORDER_SIZE = 1;

    private final String[] categories = {"APRIL", "DEFAULT", "XBOX", "MCD", "CUSTOM", "OPTIFINE", "STAFF"};

    public CapeSelectScreen() {
        super(Texts.literal("Cape Textures"));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);

        int x = PADDING;
        int categoryY = PADDING;

        for (String category : categories) {
            context.drawText(
                    Minecraft.func_71410_x().field_71466_p,
                    // 1.8.9 has no IChatComponent.formatted(); the legacy bold code is the
                    // equivalent and renders identically.
                    Texts.literal("\u00A7l" + category),
                    x,
                    categoryY, 0xFFFFFFFF, true
            );
            categoryY += 10;

            int textureX = x;
            int textureY = categoryY;

            for (Capes.CapeTextures cape : Capes.CapeTextures.values()) {
                if (cape.name().startsWith(category)) {
                    ResourceLocation texture = cape.getTexturePath();

                    drawTexture(context, texture, textureX, textureY);

                    if (cape == Capes.cape.getValue()) {
                        context.drawBorder(textureX - BORDER_SIZE, textureY - BORDER_SIZE, TEXTURE_RENDER_WIDTH + BORDER_SIZE * 2, TEXTURE_RENDER_HEIGHT + BORDER_SIZE * 2, 0xFF00FFFF);
                        context.drawBorder(textureX - BORDER_SIZE - 1, textureY - BORDER_SIZE - 1, 2 + TEXTURE_RENDER_WIDTH + BORDER_SIZE * 2, 2 + TEXTURE_RENDER_HEIGHT + BORDER_SIZE * 2, 0xFF00FFFF);
                    }
                    else if (isMouseOverTexture(mouseX, mouseY, textureX, textureY)) {
                        context.drawBorder(textureX - BORDER_SIZE, textureY - BORDER_SIZE, TEXTURE_RENDER_WIDTH + BORDER_SIZE * 2, TEXTURE_RENDER_HEIGHT + BORDER_SIZE * 2, 0xFFFFFFFF);
                    }

                    textureX += TEXTURE_RENDER_WIDTH + PADDING;
                    if (textureX + TEXTURE_RENDER_WIDTH > field_146294_l - PADDING) {
                        textureX = x;
                        textureY += TEXTURE_RENDER_HEIGHT + PADDING;
                    }
                }
            }

            categoryY = textureY + TEXTURE_RENDER_HEIGHT + 10;
        }
    }

    private boolean isMouseOverTexture(int mouseX, int mouseY, int textureX, int textureY) {
        return mouseX >= textureX && mouseX <= textureX + TEXTURE_RENDER_WIDTH &&
                mouseY >= textureY && mouseY <= textureY + TEXTURE_RENDER_HEIGHT;
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        int x = PADDING;
        int categoryY = PADDING;

        for (String category : categories) {
            categoryY += 10 + PADDING;

            int textureX = x;
            int textureY = categoryY;

            for (Capes.CapeTextures cape : Capes.CapeTextures.values()) {
                if (cape.name().startsWith(category)) {
                    if (isMouseOverTexture((int) mouseX, (int) mouseY, textureX, textureY)) {
                        Capes.cape.setValue(cape);
                        ConfigManager.saveConfig();
                        return true;
                    }

                    textureX += TEXTURE_RENDER_WIDTH + PADDING;

                    if (textureX + TEXTURE_RENDER_WIDTH > field_146294_l - PADDING) {
                        textureX = x;
                        textureY += TEXTURE_RENDER_HEIGHT + PADDING;
                    }
                }
            }

            categoryY = textureY + TEXTURE_RENDER_HEIGHT;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    private void drawTexture(DrawContext context, ResourceLocation texture, int x, int y) {
        // 1.8.9 has no render-layer parameter: DrawContext binds the texture itself.
        context.drawTexture(texture, x, y, TEXTURE_RENDER_WIDTH, TEXTURE_RENDER_HEIGHT,
                2, 2, TEXTURE_RENDER_WIDTH, TEXTURE_RENDER_HEIGHT, 128, 64);
    }
}
