package me.Padej_.soupapi.compat;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.util.IChatComponent;
import org.lwjgl.input.Mouse;

import java.io.IOException;

/**
 * Adapter from MCP 1.8.9's {@link GuiScreen} contract to the 1.21.4-style one the mod's screens
 * are written against.
 *
 * <p>The two differ substantially. 1.8.9 has:
 * <ul>
 *   <li>{@code drawScreen(int mouseX, int mouseY, float partialTicks)} with no draw context;</li>
 *   <li>{@code void mouseClicked(int, int, int)} — integer coordinates, no return value, so a
 *       screen cannot report whether it consumed the click, and it declares
 *       {@code throws IOException};</li>
 *   <li>{@code void keyTyped(char typedChar, int keyCode)} — one method for both the key and the
 *       character, where 1.21.4 split them into {@code keyPressed} and {@code charTyped};</li>
 *   <li>no scroll callback: the wheel is read from LWJGL inside {@code handleMouseInput()};</li>
 *   <li>no title, and {@code initGui()} rather than {@code init()}.</li>
 * </ul>
 *
 * <p>This class absorbs those differences so each screen keeps the newer method shapes. Return
 * values are accepted and discarded where 1.8.9 has nowhere to put them.
 *
 * <p>Escape handling is done here: 1.8.9 screens close themselves on key code 1 rather than having
 * a {@code shouldCloseOnEsc()} hook, so that hook is reproduced.
 */
public abstract class SoupScreen extends GuiScreen {

    /** LWJGL 2 reports one wheel notch as ±120. */
    private static final double WHEEL_NOTCH = 120.0;

    /** 1.8.9's {@link GuiScreen} has no title, so the port keeps one here. */
    private final IChatComponent title;

    protected SoupScreen(IChatComponent title) {
        this.title = title;
    }

    protected SoupScreen() {
        this(Texts.literal(""));
    }

    public IChatComponent getTitle() {
        return title;
    }

    // ---- 1.21.4-style methods for subclasses to override -----------------------------------

    /** Draw the screen. Called once per frame with a fresh {@link DrawContext}. */
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
    }

    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        return false;
    }

    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        return false;
    }

    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        return false;
    }

    public boolean mouseScrolled(double mouseX, double mouseY, double horizontal, double vertical) {
        return false;
    }

    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        return false;
    }

    public boolean charTyped(char chr, int modifiers) {
        return false;
    }

    public boolean shouldCloseOnEsc() {
        return true;
    }

    public void close() {
        Minecraft.func_71410_x().func_147108_a(null);
    }

    /** 1.21.4 name; 1.8.9 spells it {@code doesGuiPauseGame}. */
    public boolean shouldPause() {
        return false;
    }

    /** 1.21.4 name; 1.8.9 spells it {@code initGui}. */
    public void init() {
    }

    // ---- 1.8.9 contract --------------------------------------------------------------------

    @Override
    public void func_73866_w_() {
        super.func_73866_w_();
        init();
    }

    @Override
    public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
        super.func_73863_a(mouseX, mouseY, partialTicks);
        render(new DrawContext(Minecraft.func_71410_x()), mouseX, mouseY, partialTicks);
    }

    @Override
    protected void func_73864_a(int mouseX, int mouseY, int button) throws IOException {
        super.func_73864_a(mouseX, mouseY, button);
        mouseClicked((double) mouseX, (double) mouseY, button);
    }

    @Override
    protected void func_146286_b(int mouseX, int mouseY, int button) {
        super.func_146286_b(mouseX, mouseY, button);
        // 1.8.9 passes state -1 for "moved while held"; the newer API only reports real releases.
        if (button >= 0) {
            mouseReleased((double) mouseX, (double) mouseY, button);
        }
    }

    @Override
    protected void func_146273_a(int mouseX, int mouseY, int button, long timeSinceClick) {
        super.func_146273_a(mouseX, mouseY, button, timeSinceClick);
        // 1.8.9 gives no per-frame delta, and the mod's drag handlers track their own anchor
        // point, so zero is passed rather than a fabricated value.
        mouseDragged((double) mouseX, (double) mouseY, button, 0.0, 0.0);
    }

    @Override
    protected void func_73869_a(char typedChar, int keyCode) throws IOException {
        if (keyCode == 1 && shouldCloseOnEsc()) {
            close();
            return;
        }
        // Key first, then the character, matching 1.21.4's ordering.
        if (keyPressed(keyCode, keyCode, modifiers())) {
            return;
        }
        if (typedChar != 0) {
            charTyped(typedChar, modifiers());
        }
    }

    @Override
    public void func_146274_d() throws IOException {
        super.func_146274_d();
        int wheel;
        try {
            wheel = Mouse.getEventDWheel();
        } catch (Throwable t) {
            // Pojav's LWJGL 2 stub may not report a wheel; touch devices have none.
            return;
        }
        if (wheel != 0) {
            int mouseX = Mouse.getEventX() * this.field_146294_l / this.field_146297_k.field_71443_c;
            int mouseY = this.field_146295_m - Mouse.getEventY() * this.field_146295_m / this.field_146297_k.field_71440_d - 1;
            mouseScrolled(mouseX, mouseY, 0.0, wheel / WHEEL_NOTCH);
        }
    }

    @Override
    public boolean func_73868_f() {
        return shouldPause();
    }

    /** Packs the current modifier keys the way 1.21.4's {@code modifiers} bitmask did. */
    private static int modifiers() {
        int mods = 0;
        if (func_146272_n()) mods |= 1;
        if (func_146271_m()) mods |= 2;
        if (func_175283_s()) mods |= 4;
        return mods;
    }
}
