package me.Padej_.soupapi.compat;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;

/**
 * Window metrics, replacing 1.21.4's {@code MinecraftClient.getWindow()}.
 *
 * <p>1.8.9's equivalent is {@link ScaledResolution}, which has no accessor: it is constructed on
 * demand and recomputes the GUI scale from the current options each time. These helpers construct
 * one per call, which is what vanilla 1.8.9 code does too.
 */
public final class Windows {

    private Windows() {
    }

    private static ScaledResolution res() {
        return new ScaledResolution(Minecraft.func_71410_x());
    }

    /** GUI-space width, i.e. the coordinate space HUD rendering uses. */
    public static int scaledWidth() {
        return res().func_78326_a();
    }

    public static int scaledHeight() {
        return res().func_78328_b();
    }

    public static double scaledWidthD() {
        return res().func_78327_c();
    }

    public static double scaledHeightD() {
        return res().func_78324_d();
    }

    public static int scaleFactor() {
        return res().func_78325_e();
    }

    /** Physical framebuffer width in pixels. */
    public static int width() {
        return Minecraft.func_71410_x().field_71443_c;
    }

    public static int height() {
        return Minecraft.func_71410_x().field_71440_d;
    }
}
