package me.Padej_.soupapi.compat;

import me.Padej_.soupapi.compat.Maths;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;

/**
 * Replacement for {@code net.minecraft.client.render.Camera} as 1.21.4 exposed it.
 *
 * <p>1.8.9 <i>has</i> a {@code Camera} class, but it is a static utility holding the interpolated
 * eye position rather than an object with {@code getPos}/{@code getYaw}/{@code getPitch}. This wraps
 * the camera entity and the current frame's tick delta to provide the newer accessors, which the
 * ported world-render code calls 58 times.
 *
 * <p>Positions are interpolated between the previous and current tick exactly as vanilla's own
 * entity rendering does, so world geometry lines up with entities rather than lagging a frame.
 */
public final class Camera {

    private Entity focused;
    private float tickDelta;

    /** Refreshed once per frame by the render hook before any world rendering runs. */
    public void update(Entity focused, float tickDelta) {
        this.focused = focused;
        this.tickDelta = tickDelta;
    }

    public Entity getFocusedEntity() {
        if (focused == null) {
            Minecraft mc = Minecraft.func_71410_x();
            focused = mc.func_175606_aa() != null ? mc.func_175606_aa() : mc.field_71439_g;
        }
        return focused;
    }

    public float getTickDelta() {
        return tickDelta;
    }

    /** The interpolated eye position of the camera entity. */
    public Vec3 getPos() {
        Entity e = getFocusedEntity();
        if (e == null) {
            return new Vec3(0.0, 0.0, 0.0);
        }
        double x = e.field_70169_q + (e.field_70165_t - e.field_70169_q) * tickDelta;
        double y = e.field_70167_r + (e.field_70163_u - e.field_70167_r) * tickDelta;
        double z = e.field_70166_s + (e.field_70161_v - e.field_70166_s) * tickDelta;
        // 1.8.9 stores the entity origin at the feet; the camera sits at eye height.
        return new Vec3(x, y + e.func_70047_e(), z);
    }

    /** Alias of {@link #getPos()}; MCP spells Entity's equivalent {@code getPositionVector}. */
    public Vec3 getPositionVector() {
        return getPos();
    }

    public float getYaw() {
        Entity e = getFocusedEntity();
        if (e == null) return 0f;
        return e.field_70126_B + (e.field_70177_z - e.field_70126_B) * tickDelta;
    }

    public float getPitch() {
        Entity e = getFocusedEntity();
        if (e == null) return 0f;
        return e.field_70127_C + (e.field_70125_A - e.field_70127_C) * tickDelta;
    }

    /** Horizontal look direction, matching 1.21.4's {@code getHorizontalPlane()} usage. */
    public Vec3 getHorizontalPlane() {
        float yawRad = -Maths.wrapDegrees(getYaw()) * ((float) Math.PI / 180f);
        return new Vec3(MathHelper.func_76126_a(yawRad), 0.0, MathHelper.func_76134_b(yawRad));
    }
}
