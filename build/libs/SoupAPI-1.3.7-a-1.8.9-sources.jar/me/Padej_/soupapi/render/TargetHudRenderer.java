package me.Padej_.soupapi.render;

import me.Padej_.soupapi.compat.Maths;

import me.Padej_.soupapi.compat.RenderSystem;
import me.Padej_.soupapi.config.ConfigurableModule;
import me.Padej_.soupapi.font.FontRenderers;
import me.Padej_.soupapi.particle.Particle2D;
import me.Padej_.soupapi.reduce.ModuleSupressor;
import me.Padej_.soupapi.utils.MathUtility;
import me.Padej_.soupapi.utils.Palette;
import me.Padej_.soupapi.utils.TexturesManager;
import me.Padej_.soupapi.compat.DrawContext;
import net.minecraft.client.entity.AbstractClientPlayer;
import me.Padej_.soupapi.compat.RenderLayer;
import net.minecraft.potion.Potion;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import org.lwjgl.opengl.GL11;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

import static me.Padej_.soupapi.modules.TargetHud.smoothedScreenX;
import static me.Padej_.soupapi.modules.TargetHud.smoothedScreenY;

public class TargetHudRenderer extends ConfigurableModule {
    /** Vanilla's inventory sheet, which carries the 18x18 status-effect icons at y=198. */
    private static final ResourceLocation INVENTORY_ICONS =
            new ResourceLocation("textures/gui/container/inventory.png");

    /**
     * Resolves a vanilla effect name to its {@link Potion}.
     *
     * <p>1.8.9 has no string-keyed effect registry — {@code Potion} is a static table — so the
     * handful of names the target HUD shows are mapped explicitly.
     */
    private static Potion vanillaPotion(String name) {
        if ("speed".equals(name)) return Potion.field_76424_c;
        if ("slowness".equals(name)) return Potion.field_76421_d;
        if ("haste".equals(name)) return Potion.field_76422_e;
        if ("mining_fatigue".equals(name)) return Potion.field_76419_f;
        if ("strength".equals(name)) return Potion.field_76420_g;
        if ("jump_boost".equals(name)) return Potion.field_76430_j;
        if ("nausea".equals(name)) return Potion.field_76431_k;
        if ("regeneration".equals(name)) return Potion.field_76428_l;
        if ("resistance".equals(name)) return Potion.field_76429_m;
        if ("fire_resistance".equals(name)) return Potion.field_76426_n;
        if ("water_breathing".equals(name)) return Potion.field_76427_o;
        if ("invisibility".equals(name)) return Potion.field_76441_p;
        if ("blindness".equals(name)) return Potion.field_76440_q;
        if ("night_vision".equals(name)) return Potion.field_76439_r;
        if ("hunger".equals(name)) return Potion.field_76438_s;
        if ("weakness".equals(name)) return Potion.field_76437_t;
        if ("poison".equals(name)) return Potion.field_76436_u;
        if ("wither".equals(name)) return Potion.field_82731_v;
        if ("health_boost".equals(name)) return Potion.field_180152_w;
        if ("absorption".equals(name)) return Potion.field_76444_x;
        if ("saturation".equals(name)) return Potion.field_76443_y;
        return null;
    }

    public static final ArrayList<Particle2D> particles = new ArrayList<>();
    public static boolean sentParticles = false;
    public static float ticks = 0f;
    public static float hpColorAnimationProgress = 0f;
    public static float colorAnimationProgress = 0f;
    public static Color topLeft = new Color(0xFFFFFFFF);
    public static Color topRight = new Color(0xFFFFFFFF);
    public static Color bottomLeft = new Color(0xFFFFFFFF);
    public static Color bottomRight = new Color(0xFFFFFFFF);

    private static final String[] effectNames = {
            "absorption", "blindness", "fire_resistance", "haste", "health_boost",
            "invisibility", "jump_boost", "mining_fatigue", "poison", "regeneration",
            "resistance", "slow_falling", "slowness", "speed", "strength", "weakness", "wither"
    };

    public static void renderTinyHUD(DrawContext context, float normalizedDelta, float health, float animationFactor, EntityPlayer target, int x, int y, Vec3 screenPos) {
        float hurtPercent = (Render2D.interpolateFloat(MathUtility.clamp(target.field_70737_aN == 0 ? 0 : target.field_70737_aN + 1, 0, 10), target.field_70737_aN, normalizedDelta)) / 8f;

        Color c1 = TargetHudRenderer.topLeft;
        Color c3 = TargetHudRenderer.bottomRight;
        Color c4 = TargetHudRenderer.bottomLeft;

        // Градиентный фон с вращением цветов
        int w = 90;
        int h = 29;
        int r = 3;
        int xOffset = -4;
        int yOffset = 0;
        Render2D.drawRound(context.getMatrices(), x + xOffset, y + 0.5f + yOffset, w, h, r, Palette.getBackColor());

        // Голова игрока
        ResourceLocation texture = mc.field_71439_g.func_110306_p();
        int headScale = 25;
        if (target.func_82150_aj()) {
            texture = TexturesManager.ANON_SKIN;
        } else if (target instanceof EntityPlayer) {
            texture = ((AbstractClientPlayer) target).func_110306_p();
        }
        context.getMatrices().push();
        context.getMatrices().translate(x + 2.5 + 15, y + 2.5 + 15, 0);
        context.getMatrices().scale(1 - hurtPercent / 20f, 1 - hurtPercent / 20f, 1f);
        context.getMatrices().translate(-(x + 2.5 + 15), -(y + 2.5 + 15), 0);
        RenderSystem.enableBlend();
        RenderSystem.colorMask(false, false, false, true);
        RenderSystem.clearColor(0.0F, 0.0F, 0.0F, 0.0F);
        RenderSystem.clear(GL11.GL_COLOR_BUFFER_BIT);
        RenderSystem.colorMask(true, true, true, true);
        Render2D.drawRound(context.getMatrices(), x - 2, y + 2.5f, headScale, headScale, r, Palette.getBackColor());
        Render2D.setupRender();
        Render2D.renderRoundedQuadInternal(context.getMatrices().peek().getPositionMatrix(), animationFactor, animationFactor, animationFactor, animationFactor, x - 2, y + 2.5, x - 2 + headScale, y + 2.5 + headScale, r, 3);
        RenderSystem.blendFunc(GL11.GL_DST_ALPHA, GL11.GL_ONE_MINUS_DST_ALPHA);
        RenderSystem.setShaderColor(1f, 1f - hurtPercent / 2, 1f - hurtPercent / 2, 1f);
        Render2D.renderTexture(context.getMatrices(), texture, x - 2, y + 2.5, headScale, headScale, 8, 8, 8, 8, 64, 64);
        Render2D.renderTexture(context.getMatrices(), texture, x - 2, y + 2.5, headScale, headScale, 40, 8, 8, 8, 64, 64);
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableBlend();
        context.getMatrices().pop();

        // Партиклы
        for (final Particle2D p : particles) {
            if (p.opacity > 4) {
                float depthFactor = CONFIG.targetHudFollow ? (float) screenPos.field_72449_c : 1.0f;
                p.render2D(context.getMatrices(), smoothedScreenX, smoothedScreenY, depthFactor);
            }
        }

        if (target.field_70737_aN == 9 && !sentParticles) {
            for (int i = 0; i <= 6; i++) {
                final Particle2D p = new Particle2D();
                final Color c = Particle2D.mixColors(c1, c3, (Math.sin(ticks + x * 0.4f + i) + 1) * 0.5f);
                p.init(x - smoothedScreenX, y - smoothedScreenY, MathUtility.random(-3f, 3f), MathUtility.random(-3f, 3f), 20, c, CONFIG.targetHudFollow);
                particles.add(p);
            }
            sentParticles = true;
        }

        if (target.field_70737_aN == 8) sentParticles = false;

        int barX = x + 25;
        int barY = y + 15;
        int barHeight = 2;
        float healthBarWidth = 59;
        int innerBarWidth = (int) MathUtility.clamp((healthBarWidth * (health / target.func_110138_aP())), 8, healthBarWidth);
        Color background = new Color(0x424242);

        Render2D.drawGradientBlurredShadow1(context.getMatrices(), barX, barY, innerBarWidth, barHeight, 4, bottomLeft, bottomRight, topRight, topLeft);
        Render2D.drawGradientRound(context.getMatrices(), barX, barY, healthBarWidth - 1, barHeight, 2, background, background, background, background);
        Render2D.renderRoundedGradientRect(context.getMatrices(), c4, c3, c3, c4, barX, barY, innerBarWidth, barHeight, 2);

        RenderSystem.setShaderColor(1f, 1f, 1f, animationFactor);
        ItemStack[] armor = target.field_71071_by.field_70460_b;
        ItemStack[] items = new ItemStack[]{target.func_70694_bm(), armor[3], armor[2], armor[1], armor[0], target.func_70694_bm()};

        float xItemOffset = x + 25;
        for (ItemStack itemStack : items) {
            context.getMatrices().push();
            context.getMatrices().translate(xItemOffset, y + 4, 0);
            context.getMatrices().scale(0.5f, 0.5f, 0.5f);
            context.drawItem(itemStack, 0, 0);
            if (!ModuleSupressor.disableItemOverlay()) {
                context.drawStackOverlay(mc.field_71466_p, itemStack, 0, 0);
            }
            context.getMatrices().pop();
            xItemOffset += 10;
        }

        float effectXOffset = x + 25;
        float effectYOffset = y + 18;
        for (String effectName : effectNames) {
            Potion effect = vanillaPotion(effectName);
            if (effect != null && target.func_70644_a(effect)) {
                context.getMatrices().push();
                context.getMatrices().translate(effectXOffset, effectYOffset, 0);
                context.getMatrices().scale(0.5f, 0.5f, 0.5f);
                // 1.8.9 keeps the 18x18 effect icons on the inventory sheet at y=198, in an
                // 8-wide grid indexed by Potion.getStatusIconIndex(); there are no
                // per-effect textures/mob_effect files until 1.19.
                if (effect.func_76400_d()) {
                    int icon = effect.func_76392_e();
                    context.drawTexture(INVENTORY_ICONS, 0, 0, 18, 18,
                            (icon % 8) * 18, 198 + (icon / 8) * 18, 18, 18, 256, 256);
                }
                context.getMatrices().pop();
                effectXOffset += 10;
            }
        }

        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
    }

    public static void renderMiniHUD(DrawContext context, float normalizedDelta, float health, float animationFactor, EntityPlayer target, int x, int y, Vec3 screenPos) {
        float hurtPercent = (Render2D.interpolateFloat(MathUtility.clamp(target.field_70737_aN == 0 ? 0 : target.field_70737_aN + 1, 0, 10), target.field_70737_aN, normalizedDelta)) / 8f;

        Color c1 = Palette.getColor(0f);
        Color c3 = Palette.getColor(0.66f);

        // Градиентный фон
        Render2D.drawGradientBlurredShadow1(context.getMatrices(), x + 2, y + 2, 91, 31, 20, bottomLeft, bottomRight, topRight, topLeft);
        Render2D.renderRoundedGradientRect(context.getMatrices(), topLeft, topRight, bottomRight, bottomLeft, x, y, 95, 35, 7);
        Render2D.drawRound(context.getMatrices(), x + 0.5f, y + 0.5f, 94, 34, 7, Palette.getBackColor());

        // Голова игрока
        ResourceLocation texture = mc.field_71439_g.func_110306_p();
        String displayName = "Invisible";
        if (target.func_82150_aj()) {
            texture = TexturesManager.ANON_SKIN;
        } else if (target instanceof EntityPlayer) {
            texture = ((AbstractClientPlayer) target).func_110306_p();
            displayName = target.func_70005_c_();
        }
        context.getMatrices().push();
        context.getMatrices().translate(x + 2.5 + 15, y + 2.5 + 15, 0);
        context.getMatrices().scale(1 - hurtPercent / 20f, 1 - hurtPercent / 20f, 1f);
        context.getMatrices().translate(-(x + 2.5 + 15), -(y + 2.5 + 15), 0);
        RenderSystem.enableBlend();
        RenderSystem.colorMask(false, false, false, true);
        RenderSystem.clearColor(0.0F, 0.0F, 0.0F, 0.0F);
        RenderSystem.clear(GL11.GL_COLOR_BUFFER_BIT);
        RenderSystem.colorMask(true, true, true, true);
        Render2D.drawRound(context.getMatrices(), x + 2.5f, y + 2.5f, 30, 30, 5, Palette.getBackColor());
        Render2D.setupRender();
        Render2D.renderRoundedQuadInternal(context.getMatrices().peek().getPositionMatrix(), animationFactor, animationFactor, animationFactor, animationFactor, x + 2.5, y + 2.5, x + 2.5 + 30, y + 2.5 + 30, 5, 3);
        RenderSystem.blendFunc(GL11.GL_DST_ALPHA, GL11.GL_ONE_MINUS_DST_ALPHA);
        RenderSystem.setShaderColor(1f, 1f - hurtPercent / 2, 1f - hurtPercent / 2, 1f);
        Render2D.renderTexture(context.getMatrices(), texture, x + 2.5, y + 2.5, 30, 30, 8, 8, 8, 8, 64, 64);
        Render2D.renderTexture(context.getMatrices(), texture, x + 2.5, y + 2.5, 30, 30, 40, 8, 8, 8, 64, 64);
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableBlend();
        context.getMatrices().pop();

        for (final Particle2D p : particles) {
            if (p.opacity > 4) {
                float depthFactor = CONFIG.targetHudFollow ? Maths.clamp(1.0f - (float) screenPos.field_72449_c, 0.1f, 1.0f) : 1.0f;
                p.render2D(context.getMatrices(), smoothedScreenX, smoothedScreenY, depthFactor);
            }
        }

        if (target.field_70737_aN == 9 && !sentParticles) {
            for (int i = 0; i <= 6; i++) {
                final Particle2D p = new Particle2D();
                final Color c = Particle2D.mixColors(c1, c3, (Math.sin(ticks + x * 0.4f + i) + 1) * 0.5f);
                p.init(x - smoothedScreenX, y - smoothedScreenY, MathUtility.random(-3f, 3f), MathUtility.random(-3f, 3f), 20, c, CONFIG.targetHudFollow);
                ;
                particles.add(p);
            }
            sentParticles = true;
        }

        if (target.field_70737_aN == 8) sentParticles = false;

        // Полоска HP
        float hpProgress = hpColorAnimationProgress % 1.0f;
        Color hpLeft, hpRight;

        if (hpProgress < 0.5f) {
            float phaseProgress = hpProgress / 0.5f;
            hpLeft = interpolateColor(c1, c3, phaseProgress);
            hpRight = interpolateColor(c3, c1, phaseProgress);
        } else {
            float phaseProgress = (hpProgress - 0.5f) / 0.5f;
            hpLeft = interpolateColor(c3, c1, phaseProgress);
            hpRight = interpolateColor(c1, c3, phaseProgress);
        }

        Render2D.drawGradientRound(context.getMatrices(), x + 38, y + 25, 52, 7, 2f, c3.darker().darker(), c3.darker().darker().darker().darker(), c3.darker().darker().darker().darker(), c3.darker().darker().darker().darker());
        Render2D.renderRoundedGradientRect(context.getMatrices(), hpLeft, hpRight, hpRight, hpLeft, x + 38, y + 25, (int) MathUtility.clamp((52 * (health / target.func_110138_aP())), 8, 52), 7, 2f);

        FontRenderers.sf_bold_mini.drawCenteredString(context.getMatrices(), String.valueOf(Math.round(10.0 * health) / 10.0), x + 65, y + 27f, Render2D.applyOpacity(Palette.getTextColor(), animationFactor));
        FontRenderers.sf_bold_mini.drawString(context.getMatrices(), displayName, x + 38, y + 5, Render2D.applyOpacity(Palette.getTextColor(), animationFactor));

        RenderSystem.setShaderColor(1f, 1f, 1f, animationFactor);
        ItemStack[] armor = target.field_71071_by.field_70460_b;
        ItemStack[] items = new ItemStack[]{target.func_70694_bm(), armor[3], armor[2], armor[1], armor[0], target.func_70694_bm()};

        float xItemOffset = x + 38;
        for (ItemStack itemStack : items) {
            context.getMatrices().push();
            context.getMatrices().translate(xItemOffset, y + 13, 0);
            context.getMatrices().scale(0.5f, 0.5f, 0.5f);
            context.drawItem(itemStack, 0, 0);
            if (!ModuleSupressor.disableItemOverlay()) {
                context.drawStackOverlay(mc.field_71466_p, itemStack, 0, 0);
            }
            context.getMatrices().pop();
            xItemOffset += 9;
        }
        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
    }

    public static void renderNormalHUD(DrawContext context, float normalizedDelta, float health, float animationFactor, EntityPlayer target, int x, int y, Vec3 screenPos) {
        float hurtPercent = (Render2D.interpolateFloat(MathUtility.clamp(target.field_70737_aN == 0 ? 0 : target.field_70737_aN + 1, 0, 10), target.field_70737_aN, normalizedDelta)) / 8f;

        Color c1 = Palette.getColor(0f);
        Color c3 = Palette.getColor(0.66f);

        // Градиентный фон
        Render2D.drawGradientBlurredShadow1(context.getMatrices(), x + 2, y + 2, 133, 43, 20, bottomLeft, bottomRight, topRight, topLeft);
        Render2D.renderRoundedGradientRect(context.getMatrices(), topLeft, topRight, bottomRight, bottomLeft, x, y, 137, 47.5f, 9);
        Render2D.drawRound(context.getMatrices(), x + 0.5f, y + 0.5f, 136, 46, 9, Palette.getBackColor());

        // Голова игрока
        ResourceLocation texture = mc.field_71439_g.func_110306_p();
        String displayName = "Invisible";
        if (target.func_82150_aj()) {
            texture = TexturesManager.ANON_SKIN;
        } else if (target instanceof EntityPlayer) {
            texture = ((AbstractClientPlayer) target).func_110306_p();
            displayName = target.func_70005_c_();
        }
        context.getMatrices().push();
        context.getMatrices().translate(x + 3.5f + 20, y + 3.5f + 20, 0);
        context.getMatrices().scale(1 - hurtPercent / 15f, 1 - hurtPercent / 15f, 1f);
        context.getMatrices().translate(-(x + 3.5f + 20), -(y + 3.5f + 20), 0);
        RenderSystem.enableBlend();
        RenderSystem.colorMask(false, false, false, true);
        RenderSystem.clearColor(0.0F, 0.0F, 0.0F, 0.0F);
        RenderSystem.clear(GL11.GL_COLOR_BUFFER_BIT);
        RenderSystem.colorMask(true, true, true, true);
        Render2D.drawRound(context.getMatrices(), x + 3.5f, y + 3.5f, 40, 40, 7, Palette.getBackColor());
        Render2D.setupRender();
        Render2D.renderRoundedQuadInternal(context.getMatrices().peek().getPositionMatrix(), animationFactor, animationFactor, animationFactor, animationFactor, x + 3.5f, y + 3.5f, x + 3.5f + 40, y + 3.5f + 40, 7, 3);
        RenderSystem.blendFunc(GL11.GL_DST_ALPHA, GL11.GL_ONE_MINUS_DST_ALPHA);
        RenderSystem.setShaderColor(1f, 1f - hurtPercent / 2, 1f - hurtPercent / 2, 1f);
        Render2D.renderTexture(context.getMatrices(), texture, x + 3.5f, y + 3.5f, 40, 40, 8, 8, 8, 8, 64, 64);
        Render2D.renderTexture(context.getMatrices(), texture, x + 3.5f, y + 3.5f, 40, 40, 40, 8, 8, 8, 64, 64);
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableBlend();
        context.getMatrices().pop();

        // Партиклы
        for (final Particle2D p : particles) {
            if (p.opacity > 4) {
                float depthFactor = CONFIG.targetHudFollow ? Maths.clamp(1.0f - (float) screenPos.field_72449_c, 0.1f, 1.0f) : 1.0f;
                p.render2D(context.getMatrices(), smoothedScreenX, smoothedScreenY, depthFactor);
            }
        }

        if (target.field_70737_aN == 9 && !sentParticles) {
            for (int i = 0; i <= 6; i++) {
                final Particle2D p = new Particle2D();
                final Color c = Particle2D.mixColors(c1, c3, (Math.sin(ticks + x * 0.4f + i) + 1) * 0.5f);
                p.init(x - smoothedScreenX, y - smoothedScreenY, MathUtility.random(-3f, 3f), MathUtility.random(-3f, 3f), 20, c, CONFIG.targetHudFollow);
                ;
                particles.add(p);
            }
            sentParticles = true;
        }

        if (target.field_70737_aN == 8) sentParticles = false;

        // Полоска HP
        float hpProgress = hpColorAnimationProgress % 1.0f;
        Color hpLeft, hpRight;

        if (hpProgress < 0.5f) {
            float phaseProgress = hpProgress / 0.5f;
            hpLeft = interpolateColor(c1, c3, phaseProgress);
            hpRight = interpolateColor(c3, c1, phaseProgress);
        } else {
            float phaseProgress = (hpProgress - 0.5f) / 0.5f;
            hpLeft = interpolateColor(c3, c1, phaseProgress);
            hpRight = interpolateColor(c1, c3, phaseProgress);
        }

        Render2D.drawGradientRound(context.getMatrices(), x + 48, y + 32, 85, 11, 4f, c3.darker().darker(), c3.darker().darker().darker().darker(), c3.darker().darker().darker().darker(), c3.darker().darker().darker().darker());
        Render2D.renderRoundedGradientRect(context.getMatrices(), hpLeft, hpRight, hpRight, hpLeft, x + 48, y + 32, (int) MathUtility.clamp((85 * (health / target.func_110138_aP())), 8, 85), 11, 4f);

        FontRenderers.sf_bold.drawCenteredString(context.getMatrices(), String.valueOf(Math.round(10.0 * health) / 10.0), x + 92f, y + 35f, Render2D.applyOpacity(Palette.getTextColor(), animationFactor));
        FontRenderers.sf_bold.drawString(context.getMatrices(), displayName, x + 48, y + 7, Render2D.applyOpacity(Palette.getTextColor(), animationFactor));

        RenderSystem.setShaderColor(1f, 1f, 1f, animationFactor);
        ItemStack[] armor = target.field_71071_by.field_70460_b;
        ItemStack[] items = new ItemStack[]{target.func_70694_bm(), armor[3], armor[2], armor[1], armor[0], target.func_70694_bm()};

        float xItemOffset = x + 48;
        for (ItemStack itemStack : items) {
            context.getMatrices().push();
            context.getMatrices().translate(xItemOffset, y + 15, 0);
            context.getMatrices().scale(0.75f, 0.75f, 0.75f);
            context.drawItem(itemStack, 0, 0);
            if (!ModuleSupressor.disableItemOverlay()) {
                context.drawStackOverlay(mc.field_71466_p, itemStack, 0, 0);
            }
            context.getMatrices().pop();
            xItemOffset += 12;
        }
        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
    }

    public static void renderAresHUD(DrawContext context, float normalizedDelta, float health, float animationFactor, EntityPlayer target, int x, int y, Vec3 screenPos) {
        float hurtPercent = (Render2D.interpolateFloat(MathUtility.clamp(target.field_70737_aN == 0 ? 0 : target.field_70737_aN + 1, 0, 10), target.field_70737_aN, normalizedDelta)) / 8f;

        Color c1 = Palette.getColor(0f);
        Color c3 = Palette.getColor(0.66f);

        ResourceLocation texture = mc.field_71439_g.func_110306_p();
        String displayName = "Invisible";
        if (target.func_82150_aj()) {
            texture = TexturesManager.ANON_SKIN;
        } else if (target instanceof EntityPlayer) {
            texture = ((AbstractClientPlayer) target).func_110306_p();
            displayName = target.func_70005_c_();
        }

        int textWidth = (int) FontRenderers.sf_bold_17.getStringWidth(displayName);
        int minWidth = 120;
        int padding = 50;
        int totalWidthBackground = Math.max(minWidth, textWidth + padding);
        int healthBarWidth = totalWidthBackground - 52;

        // Градиентный фон
        Render2D.drawRound(context.getMatrices(), x + 0.5f, y + 0.5f, totalWidthBackground, 46, 7, Palette.getBackColor());

        float headScale = 20;
        context.getMatrices().push();
        context.getMatrices().translate(x + 3.5f + headScale, y + 3.5f + headScale, 0);
        context.getMatrices().scale(1 - hurtPercent / 15f, 1 - hurtPercent / 15f, 1f);
        context.getMatrices().translate(-(x + 3.5f + headScale), -(y + 3.5f + headScale), 0);
        RenderSystem.enableBlend();
        RenderSystem.colorMask(false, false, false, true);
        RenderSystem.clearColor(0.0F, 0.0F, 0.0F, 0.0F);
        RenderSystem.clear(GL11.GL_COLOR_BUFFER_BIT);
        RenderSystem.colorMask(true, true, true, true);
        Render2D.drawRound(context.getMatrices(), x + 3.5f, y + 3.5f, 40, 40, 5, Palette.getBackColor());
        Render2D.setupRender();
        Render2D.renderRoundedQuadInternal(context.getMatrices().peek().getPositionMatrix(), animationFactor, animationFactor, animationFactor, animationFactor, x + 3.5f, y + 3.5f, x + 3.5f + headScale * 2, y + 3.5f + headScale * 2, 5, 3);
        RenderSystem.blendFunc(GL11.GL_DST_ALPHA, GL11.GL_ONE_MINUS_DST_ALPHA);
        RenderSystem.setShaderColor(1f, 1f - hurtPercent / 2, 1f - hurtPercent / 2, 1f);
        Render2D.renderTexture(context.getMatrices(), texture, x + 3.5f, y + 3.5f, headScale * 2, headScale * 2, 8, 8, 8, 8, 64, 64);
        Render2D.renderTexture(context.getMatrices(), texture, x + 3.5f, y + 3.5f, headScale * 2, headScale * 2, 40, 8, 8, 8, 64, 64);
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableBlend();
        context.getMatrices().pop();

        // Партиклы
        for (final Particle2D p : particles) {
            if (p.opacity > 4) {
                float depthFactor = CONFIG.targetHudFollow ? Maths.clamp(1.0f - (float) screenPos.field_72449_c, 0.1f, 1.0f) : 1.0f;
                p.render2D(context.getMatrices(), smoothedScreenX, smoothedScreenY, depthFactor);
            }
        }

        if (target.field_70737_aN == 9 && !sentParticles) {
            for (int i = 0; i <= 6; i++) {
                final Particle2D p = new Particle2D();
                final Color c = Particle2D.mixColors(c1, c3, (Math.sin(ticks + x * 0.4f + i) + 1) * 0.5f);
                p.init(x - smoothedScreenX, y - smoothedScreenY, MathUtility.random(-3f, 3f), MathUtility.random(-3f, 3f), 20, c, CONFIG.targetHudFollow);
                particles.add(p);
            }
            sentParticles = true;
        }

        if (target.field_70737_aN == 8) sentParticles = false;

        // Полоска HP
        float hpProgress = hpColorAnimationProgress % 1.0f;
        Color hpLeft, hpRight;

        if (hpProgress < 0.5f) {
            float phaseProgress = hpProgress / 0.5f;
            hpLeft = interpolateColor(c1, c3, phaseProgress);
            hpRight = interpolateColor(c3, c1, phaseProgress);
        } else {
            float phaseProgress = (hpProgress - 0.5f) / 0.5f;
            hpLeft = interpolateColor(c3, c1, phaseProgress);
            hpRight = interpolateColor(c1, c3, phaseProgress);
        }

        int barX = x + 48;
        int barY = y + 32;
        int barHeight = 9;
        int innerBarWidth = (int) MathUtility.clamp((healthBarWidth * (health / target.func_110138_aP())), 8, healthBarWidth);
        Color background = Palette.getBackColor().darker().darker().darker();

        Render2D.drawGradientRound(context.getMatrices(), barX, barY, healthBarWidth - 1, barHeight, 2, background, background, background, background);
        Render2D.drawGradientBlurredShadow1(context.getMatrices(), barX, barY, innerBarWidth, barHeight, 4, bottomLeft, bottomRight, topRight, topLeft);
        Render2D.renderRoundedGradientRect(context.getMatrices(), hpLeft, hpRight, hpRight, hpLeft, barX, barY, innerBarWidth, barHeight, 2);

        FontRenderers.sf_bold_17.drawString(context.getMatrices(), displayName, x + 48, y + 7, Render2D.applyOpacity(Palette.getTextColor(), animationFactor));
        FontRenderers.sf_bold.drawString(context.getMatrices(), "HP: " + Math.round(10.0 * health) / 10.0, x + 48, y + 20, Render2D.applyOpacity(Palette.getTextColor(), animationFactor));

        RenderSystem.setShaderColor(1f, 1f, 1f, animationFactor);
        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
    }


    public static void renderAlt_1_HUD(DrawContext context, float normalizedDelta, float health, float animationFactor, EntityPlayer target, int x, int y, Vec3 screenPos) {
        float hurtPercent = (Render2D.interpolateFloat(MathUtility.clamp(target.field_70737_aN == 0 ? 0 : target.field_70737_aN + 1, 0, 10), target.field_70737_aN, normalizedDelta)) / 8f;

        Color c1 = TargetHudRenderer.topLeft;
        Color c3 = TargetHudRenderer.bottomRight;
        Color c4 = TargetHudRenderer.bottomLeft;

        // Градиентный фон
        int w = 90;
        int h = 33;
        int r = 3;
        int xOffset = -5;
        int yOffset = 0;
        Render2D.drawRound(context.getMatrices(), x + xOffset, y + 0.5f + yOffset, w, h, r, Palette.getBackColor());

        // Голова игрока
        ResourceLocation texture = mc.field_71439_g.func_110306_p();
        String displayName = "Invisible";
        int headScale = 20;
        if (target.func_82150_aj()) {
            texture = TexturesManager.ANON_SKIN;
        } else if (target instanceof EntityPlayer) {
            texture = ((AbstractClientPlayer) target).func_110306_p();
            displayName = target.func_70005_c_();
        }
        context.getMatrices().push();
        context.getMatrices().translate(x + 2.5 + 15, y + 2.5 + 15, 0);
        context.getMatrices().scale(1 - hurtPercent / 20f, 1 - hurtPercent / 20f, 1f);
        context.getMatrices().translate(-(x + 2.5 + 15), -(y + 2.5 + 15), 0);
        RenderSystem.enableBlend();
        RenderSystem.colorMask(false, false, false, true);
        RenderSystem.clearColor(0.0F, 0.0F, 0.0F, 0.0F);
        RenderSystem.clear(GL11.GL_COLOR_BUFFER_BIT);
        RenderSystem.colorMask(true, true, true, true);
        Render2D.drawRound(context.getMatrices(), x - 2, y + 2.5f, headScale, headScale, r, Palette.getBackColor());
        Render2D.setupRender();
        Render2D.renderRoundedQuadInternal(context.getMatrices().peek().getPositionMatrix(), animationFactor, animationFactor, animationFactor, animationFactor, x - 2, y + 2.5, x - 2 + headScale, y + 2.5 + headScale, r, 3);
        RenderSystem.blendFunc(GL11.GL_DST_ALPHA, GL11.GL_ONE_MINUS_DST_ALPHA);
        RenderSystem.setShaderColor(1f, 1f - hurtPercent / 2, 1f - hurtPercent / 2, 1f);
        Render2D.renderTexture(context.getMatrices(), texture, x - 2, y + 2.5, headScale, headScale, 8, 8, 8, 8, 64, 64);
        Render2D.renderTexture(context.getMatrices(), texture, x - 2, y + 2.5, headScale, headScale, 40, 8, 8, 8, 64, 64);
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableBlend();
        context.getMatrices().pop();

        // Партиклы
        for (final Particle2D p : particles) {
            if (p.opacity > 4) {
                float depthFactor = CONFIG.targetHudFollow ? (float) screenPos.field_72449_c : 1.0f;
                p.render2D(context.getMatrices(), smoothedScreenX, smoothedScreenY, depthFactor);
            }
        }

        if (target.field_70737_aN == 9 && !sentParticles) {
            for (int i = 0; i <= 6; i++) {
                final Particle2D p = new Particle2D();
                final Color c = Particle2D.mixColors(c1, c3, (Math.sin(ticks + x * 0.4f + i) + 1) * 0.5f);
                p.init(x - smoothedScreenX, y - smoothedScreenY, MathUtility.random(-3f, 3f), MathUtility.random(-3f, 3f), 20, c, CONFIG.targetHudFollow);
                particles.add(p);
            }
            sentParticles = true;
        }

        if (target.field_70737_aN == 8) sentParticles = false;

        int barX = x - 2;
        int barY = y + 27;
        int barHeight = 2;
        float healthBarWidth = 84;
        int innerBarWidth = (int) MathUtility.clamp((healthBarWidth * (health / target.func_110138_aP())), 8, healthBarWidth);
        Color background = new Color(0x424242);

        FontRenderers.sf_bold_12.drawString(context.getMatrices(), displayName, x + 20, y + 6, Render2D.applyOpacity(Palette.getTextColor(), animationFactor));

        Render2D.drawGradientBlurredShadow1(context.getMatrices(), barX, barY, innerBarWidth, barHeight, 4, bottomLeft, bottomRight, topRight, topLeft);
        Render2D.drawGradientRound(context.getMatrices(), barX, barY, healthBarWidth - 1, barHeight, 1, background, background, background, background);
        Render2D.renderRoundedGradientRect(context.getMatrices(), c4, c3, c3, c4, barX, barY, innerBarWidth, barHeight, 1);

        RenderSystem.setShaderColor(1f, 1f, 1f, animationFactor);
        ItemStack[] armor = target.field_71071_by.field_70460_b;
        ItemStack[] items = new ItemStack[]{target.func_70694_bm(), armor[3], armor[2], armor[1], armor[0], target.func_70694_bm()};

        float xItemOffset = x + 20;
        float yItemOffset = y + 12;
        float itemGap = 10;
        float itemScale = 0.5f;
        for (ItemStack itemStack : items) {
            context.getMatrices().push();
            context.getMatrices().translate(xItemOffset, yItemOffset, 0);
            context.getMatrices().scale(itemScale, itemScale, itemScale);
            context.drawItem(itemStack, 0, 0);
            if (!ModuleSupressor.disableItemOverlay()) {
                context.drawStackOverlay(mc.field_71466_p, itemStack, 0, 0);
            }
            context.getMatrices().pop();
            xItemOffset += itemGap;
        }

        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
    }

    private static Color interpolateColor(Color start, Color end, float progress) {
        int r = Math.round(Maths.lerp(progress, start.getRed(), end.getRed()));
        int g = Math.round(Maths.lerp(progress, start.getGreen(), end.getGreen()));
        int b = Math.round(Maths.lerp(progress, start.getBlue(), end.getBlue()));
        int a = Math.round(Maths.lerp(progress, start.getAlpha(), end.getAlpha()));
        return new Color(r, g, b, a);
    }
}
