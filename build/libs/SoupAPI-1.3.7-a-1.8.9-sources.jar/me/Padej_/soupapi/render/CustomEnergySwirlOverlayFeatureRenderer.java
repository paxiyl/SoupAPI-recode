package me.Padej_.soupapi.render;

import net.minecraft.client.renderer.GlStateManager;
import me.Padej_.soupapi.compat.RenderSystem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.layers.LayerRenderer;
import net.minecraft.client.model.ModelBase;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

/**
 * Re-renders an entity's model with a scrolling, additively blended overlay texture — the
 * "charged creeper" look, applied to arbitrary entities.
 *
 * <p>Fully rewritten for 1.8.9. The 1.21.4 version obtained a {@code VertexConsumer} for a render
 * layer carrying an {@code OffsetTexturing} phase and submitted the model into it. 1.8.9 draws
 * immediately and animates such overlays by translating the <i>texture matrix</i>, so this follows
 * vanilla 1.8.9's own charged-creeper feature renderer: bind the overlay texture, scroll the
 * texture matrix, switch to additive blending with lighting off, draw the model again, then restore
 * every piece of state it touched.
 *
 * <p>Restoring state matters more here than it did in 1.21.4: the fixed-function pipeline is
 * global, so a leaked texture matrix or blend func would corrupt everything drawn afterwards in the
 * frame.
 */
public abstract class CustomEnergySwirlOverlayFeatureRenderer<E extends EntityLivingBase>
        implements LayerRenderer<E> {

    @Override
    public void func_177141_a(E entity, float limbAngle, float limbDistance, float tickDelta,
                              float age, float headYaw, float headPitch, float scale) {
        if (!shouldRender(entity)) return;

        ModelBase model = getEnergySwirlModel();
        if (model == null) return;

        boolean invisible = entity.func_82150_aj();
        GlStateManager.func_179132_a(!invisible);

        Minecraft.func_71410_x().func_110434_K().func_110577_a(getEnergySwirlTexture());

        GlStateManager.func_179128_n(GL11.GL_TEXTURE);
        GlStateManager.func_179094_E();
        GlStateManager.func_179096_D();
        float offset = getEnergySwirlX(age) % 1.0f;
        GlStateManager.func_179109_b(offset, offset, 0f);
        GlStateManager.func_179128_n(GL11.GL_MODELVIEW);

        GlStateManager.func_179147_l();
        // Additive, matching the 1.21.4 layer's ADDITIVE_TRANSPARENCY.
        GlStateManager.func_179112_b(GL11.GL_ONE, GL11.GL_ONE);
        GlStateManager.func_179140_f();
        GlStateManager.func_179131_c(0.5f, 0.5f, 0.5f, 1.0f);

        try {
            model.func_78088_a(entity, limbAngle, limbDistance, age, headYaw, headPitch, scale);
        } finally {
            // Restore: the fixed-function pipeline is global state.
            GlStateManager.func_179128_n(GL11.GL_TEXTURE);
            GlStateManager.func_179121_F();
            GlStateManager.func_179128_n(GL11.GL_MODELVIEW);

            GlStateManager.func_179145_e();
            RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
            RenderSystem.defaultBlendFunc();
            GlStateManager.func_179084_k();
            GlStateManager.func_179132_a(true);
        }
    }

    @Override
    public boolean func_177142_b() {
        return false;
    }

    protected abstract boolean shouldRender(E entity);

    /** Texture-coordinate scroll for the given entity age, in texture units per tick. */
    protected abstract float getEnergySwirlX(float partialAge);

    protected abstract ResourceLocation getEnergySwirlTexture();

    protected abstract ModelBase getEnergySwirlModel();
}
