package me.Padej_.soupapi.modules;

import me.Padej_.soupapi.compat.Cameras;

import me.Padej_.soupapi.compat.BlendFactor;

import net.minecraft.client.renderer.GlStateManager;
import me.Padej_.soupapi.compat.RenderSystem;
import me.Padej_.soupapi.config.ConfigurableModule;
import me.Padej_.soupapi.render.Render2D;
import me.Padej_.soupapi.utils.EntityUtils;
import me.Padej_.soupapi.utils.Palette;
import me.Padej_.soupapi.utils.TexturesManager;
import me.Padej_.soupapi.utils.Timer;
import me.Padej_.soupapi.event.WorldRenderContext;
import me.Padej_.soupapi.event.AttackEntityCallback;
import me.Padej_.soupapi.compat.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.MovingObjectPosition;
import me.Padej_.soupapi.compat.RotationAxis;
import net.minecraft.util.Vec3;

import java.util.ArrayList;

public class HitBubbles extends ConfigurableModule {

    private static final ArrayList<HitBubble> bubbles = new ArrayList<>();
    private static long lastHitTime = 0;

    public static void registerOnHit() {
        AttackEntityCallback.EVENT.register((playerEntity, world, hand, entity, hitResult) -> {
            if ((entity instanceof EntityLivingBase && !EntityUtils.isFriend(entity) && !EntityUtils.isSpectator(entity)) && CONFIG.hitBubblesEnabled) {
                long now = System.currentTimeMillis();
                if (now - lastHitTime < 150) return AttackEntityCallback.Result.PASS; // защита от спама (150мс)
                lastHitTime = now;

                float yaw = playerEntity.rotationYaw;
                float pitch = playerEntity.rotationPitch;
                double distance = 5.0;
                Vec3 point = getRtxPoint(yaw, pitch, distance);

                if (point != null) {
                    bubbles.add(new HitBubble(
                            (float) point.xCoord, (float) point.yCoord, (float) point.zCoord,
                            -yaw, pitch, new Timer()
                    ));
                }
            }
            return AttackEntityCallback.Result.PASS;
        });
    }

    public static void render(WorldRenderContext context) {
        RenderSystem.disableDepthTest();
        ArrayList<HitBubble> copy = new ArrayList<>(bubbles);
        MatrixStack matrixStack = context.matrixStack();

        for (HitBubble b : copy) {
            matrixStack.push();
            matrixStack.translate(
                    b.x - Cameras.get().getPositionVector().field_72450_a,
                    b.y - Cameras.get().getPositionVector().field_72448_b,
                    b.z - Cameras.get().getPositionVector().field_72449_c
            );
            matrixStack.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(b.yaw));
            matrixStack.multiply(RotationAxis.POSITIVE_X.rotationDegrees(b.pitch));

            float angle = -b.life.getPassedTimeMs() / 4f;
            float factor = b.life.getPassedTimeMs() / (CONFIG.hitBubblesRenderTime * 50f);
            drawBubble(matrixStack, angle, factor);

            matrixStack.pop();
        }

        RenderSystem.enableDepthTest();
        bubbles.removeIf(b -> b.life.passedMs(CONFIG.hitBubblesRenderTime * 50L));
    }

    private static void drawBubble(MatrixStack matrices, float angle, float factor) {
        Render2D.setupRender();
        RenderSystem.disableCull();
        RenderSystem.blendFunc(BlendFactor.SrcFactor.SRC_ALPHA, BlendFactor.DstFactor.ONE);
        RenderSystem.setShaderTexture(0, TexturesManager.getHitBubbleTexture());

        matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(angle));
        float scale = factor * 2f * (CONFIG.hitBubblesScale / 100f);
        Render2D.renderGradientTexture(matrices,
                -scale / 2, -scale / 2, scale, scale,
                0, 0, 128, 128, 128, 128,
                Render2D.applyOpacity(Palette.getColor(0), 1f - factor),
                Render2D.applyOpacity(Palette.getColor(0.33f), 1f - factor),
                Render2D.applyOpacity(Palette.getColor(0.66f), 1f - factor),
                Render2D.applyOpacity(Palette.getColor(1), 1f - factor));
        Render2D.endRender();
        RenderSystem.enableCull();
    }

    /**
     * Finds where the player's look ray first meets a living entity, or {@code null}.
     *
     * <p>1.8.9 has no {@code ProjectileUtil.raycast} and no {@code EntityHitResult}, so the sweep
     * is done directly: collect entities within the ray's expanded bounding box, intersect the ray
     * with each one's box, and keep the nearest hit. This is the same algorithm vanilla 1.8.9 uses
     * for the player's own reach check in {@code EntityRenderer.getMouseOver}.
     */
    private static Vec3 getRtxPoint(float yaw, float pitch, double distance) {
        if (mc.field_71439_g == null || mc.field_71441_e == null) return null;

        Vec3 from = mc.field_71439_g.func_174791_d()
                .func_72441_c(0, mc.field_71439_g.func_70047_e(), 0);
        Vec3 direction = getRotationVector(pitch, yaw);
        Vec3 to = from.func_72441_c(direction.field_72450_a * distance,
                direction.field_72448_b * distance,
                direction.field_72449_c * distance);

        AxisAlignedBB sweep = mc.field_71439_g.func_174813_aQ()
                .func_72321_a(direction.field_72450_a * distance,
                        direction.field_72448_b * distance,
                        direction.field_72449_c * distance)
                .func_72314_b(1.0, 1.0, 1.0);

        Vec3 nearestHit = null;
        double nearestSq = distance * distance;

        java.util.List<Entity> candidates =
                mc.field_71441_e.func_72839_b(mc.field_71439_g, sweep);
        for (int i = 0; i < candidates.size(); i++) {
            Entity entity = candidates.get(i);
            if (!(entity instanceof EntityLivingBase)) continue;
            if (EntityUtils.isSpectator(entity) || !entity.func_70067_L()) continue;

            float border = entity.func_70111_Y();
            AxisAlignedBB box = entity.func_174813_aQ().func_72314_b(border, border, border);
            MovingObjectPosition hit = box.func_72327_a(from, to);
            if (hit == null) continue;

            double distSq = from.func_72436_e(hit.field_72307_f);
            if (distSq < nearestSq) {
                nearestSq = distSq;
                nearestHit = hit.field_72307_f;
            }
        }
        return nearestHit;
    }

    private static Vec3 getRotationVector(float pitch, float yaw) {
        float f = (float) Math.cos(-yaw * 0.017453292F - Math.PI);
        float g = (float) Math.sin(-yaw * 0.017453292F - Math.PI);
        float h = (float) -Math.cos(-pitch * 0.017453292F);
        float i = (float) Math.sin(-pitch * 0.017453292F);
        return new Vec3(g * h, i, f * h);
    }

    public enum Style {
        CIRCLE, CIRCLE_BOLD, HEXAGON, PORTAL, PORTAL_2
    }
public static final class HitBubble {
    private final float x;
    private final float y;
    private final float z;
    private final float yaw;
    private final float pitch;
    private final Timer life;

    public HitBubble(float x, float y, float z, float yaw, float pitch, Timer life) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.yaw = yaw;
        this.pitch = pitch;
        this.life = life;
    }

    public float x() {
        return x;
    }

    public float y() {
        return y;
    }

    public float z() {
        return z;
    }

    public float yaw() {
        return yaw;
    }

    public float pitch() {
        return pitch;
    }

    public Timer life() {
        return life;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof HitBubble)) return false;
        HitBubble other = (HitBubble) o;
        if (Float.compare(x, other.x) != 0) return false;
        if (Float.compare(y, other.y) != 0) return false;
        if (Float.compare(z, other.z) != 0) return false;
        if (Float.compare(yaw, other.yaw) != 0) return false;
        if (Float.compare(pitch, other.pitch) != 0) return false;
        if (life == null ? other.life != null : !life.equals(other.life)) return false;
        return true;
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = 31 * result + Float.floatToIntBits(x);
        result = 31 * result + Float.floatToIntBits(y);
        result = 31 * result + Float.floatToIntBits(z);
        result = 31 * result + Float.floatToIntBits(yaw);
        result = 31 * result + Float.floatToIntBits(pitch);
        result = 31 * result + (life == null ? 0 : life.hashCode());
        return result;
    }

    @Override
    public String toString() {
        return "HitBubble[" + "x=" + x + ", " + "y=" + y + ", " + "z=" + z + ", " + "yaw=" + yaw + ", " + "pitch=" + pitch + ", " + "life=" + life + "]";
    }
    }
}
