package me.Padej_.soupapi.modules;

import me.Padej_.soupapi.config.ConfigurableModule;
import me.Padej_.soupapi.event.WorldRenderContext;
import me.Padej_.soupapi.render.Render2D;
import me.Padej_.soupapi.render.Render3D_Shapes;
import me.Padej_.soupapi.utils.Palette;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBow;
import net.minecraft.item.ItemEgg;
import net.minecraft.item.ItemEnderPearl;
import net.minecraft.item.ItemExpBottle;
import net.minecraft.item.ItemPotion;
import net.minecraft.item.ItemSnowball;
import net.minecraft.item.ItemStack;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;

import java.awt.Color;

/**
 * Draws the predicted flight path of the held projectile.
 *
 * <p>Reduced to what 1.8.9 actually has. Dropped from the 1.21.4 version:
 * <ul>
 *   <li><b>Crossbows</b> and their Multishot triple-trajectory — crossbows are 1.14+.</li>
 *   <li><b>The off-hand</b> — added in 1.9, so only the held item is considered.</li>
 *   <li><b>Tridents</b> and <b>lingering potions</b> — 1.13 and 1.9 respectively.</li>
 * </ul>
 *
 * <p>Splash potions are still handled: in 1.8.9 they are {@code ItemPotion} with the splash flag
 * set rather than a distinct class.
 *
 * <p>The collision walk uses {@code World.rayTraceBlocks(Vec3, Vec3)}; 1.8.9 has no
 * {@code RaycastContext} with selectable shape and fluid handling.
 */
public class Trajectories extends ConfigurableModule {

    public static void onTick() {
    }

    public static void render(WorldRenderContext context) {
        if (mc.field_71474_y.field_74319_N) return;
        if (mc.field_71439_g == null || mc.field_71441_e == null
                || mc.field_71474_y.field_74320_O != 0
                || !CONFIG.trajectoriesPreviewEnabled) {
            return;
        }

        float tickDelta = context.tickCounter().getTickDelta(true);
        ItemStack held = mc.field_71439_g.func_70694_bm();
        if (held == null || held.func_77973_b() == null) return;

        Item item = held.func_77973_b();
        if (!(item instanceof ItemBow) && !isThrowable(item)) return;

        // View bobbing would make the preview wobble away from where the projectile will go.
        boolean prevBob = mc.field_71474_y.field_74336_f;
        mc.field_71474_y.field_74336_f = false;
        try {
            calcTrajectory(item, mc.field_71439_g.field_70177_z, tickDelta);
        } finally {
            mc.field_71474_y.field_74336_f = prevBob;
        }
    }

    private static boolean isThrowable(Item item) {
        return item instanceof ItemEnderPearl
                || item instanceof ItemExpBottle
                || item instanceof ItemSnowball
                || item instanceof ItemEgg
                || item instanceof ItemPotion;
    }

    private static float getDistance(Item item) {
        return item instanceof ItemBow ? 1.0f : 0.4f;
    }

    private static float getThrowVelocity(Item item) {
        if (item instanceof ItemPotion) return 0.5f;
        if (item instanceof ItemExpBottle) return 0.59f;
        return 1.5f;
    }

    private static int getThrowPitch(Item item) {
        if (item instanceof ItemPotion || item instanceof ItemExpBottle) return 20;
        return 0;
    }

    private static void calcTrajectory(Item item, float yaw, float tickDelta) {
        EntityPlayerSP player = mc.field_71439_g;
        if (player == null) return;

        double x = Render2D.interpolate(player.field_70169_q, player.field_70165_t, tickDelta);
        double y = Render2D.interpolate(player.field_70167_r, player.field_70163_u, tickDelta);
        double z = Render2D.interpolate(player.field_70166_s, player.field_70161_v, tickDelta);

        y = y + player.func_70047_e() - 0.1000000014901161;

        // 1.8.9 only ever throws from the main hand, so the offset is always the left-hand one.
        x = x - MathHelper.func_76134_b(yaw / 180.0f * 3.1415927f) * 0.16f;
        z = z - MathHelper.func_76126_a(yaw / 180.0f * 3.1415927f) * 0.16f;

        final float maxDist = getDistance(item);
        double motionX = -MathHelper.func_76126_a(yaw / 180.0f * 3.1415927f)
                * MathHelper.func_76134_b(player.field_70125_A / 180.0f * 3.1415927f) * maxDist;
        double motionY = -MathHelper.func_76126_a((player.field_70125_A - getThrowPitch(item)) / 180.0f * 3.141593f) * maxDist;
        double motionZ = MathHelper.func_76134_b(yaw / 180.0f * 3.1415927f)
                * MathHelper.func_76134_b(player.field_70125_A / 180.0f * 3.1415927f) * maxDist;

        float power = player.func_71057_bx() / 20.0f;
        power = (power * power + power * 2.0f) / 3.0f;
        if (power > 1.0f || power == 0) {
            power = 1.0f;
        }

        final float distance = MathHelper.func_76133_a(
                motionX * motionX + motionY * motionY + motionZ * motionZ);
        if (distance == 0f) return;
        motionX /= distance;
        motionY /= distance;
        motionZ /= distance;

        final float pow = (item instanceof ItemBow ? (power * 2.0f) : 1.0f) * getThrowVelocity(item);
        motionX *= pow;
        motionY *= pow;
        motionZ *= pow;
        if (!player.field_70122_E) {
            motionY += player.field_70181_x;
        }

        Color color = Render2D.injectAlpha(Palette.getColor(0.33f), 220).brighter();

        for (int i = 0; i < 300; i++) {
            Vec3 lastPos = new Vec3(x, y, z);
            x += motionX;
            y += motionY;
            z += motionZ;

            if (mc.field_71441_e.func_180495_p(new BlockPos((int) x, (int) y, (int) z)).func_177230_c() == Blocks.field_150355_j) {
                motionX *= 0.8;
                motionY *= 0.8;
                motionZ *= 0.8;
            } else {
                motionX *= 0.99;
                motionY *= 0.99;
                motionZ *= 0.99;
            }

            motionY -= item instanceof ItemBow ? 0.05000000074505806 : 0.03f;

            Vec3 pos = new Vec3(x, y, z);
            MovingObjectPosition hit = mc.field_71441_e.func_72933_a(lastPos, pos);
            if (hit != null && hit.field_72313_a == MovingObjectPosition.MovingObjectType.BLOCK) {
                BlockPos blockPos = hit.func_178782_a();
                AxisAlignedBB box = AxisAlignedBB.func_178781_a(
                        blockPos.func_177958_n(), blockPos.func_177956_o(), blockPos.func_177952_p(),
                        blockPos.func_177958_n() + 1, blockPos.func_177956_o() + 1, blockPos.func_177952_p() + 1);
                if (CONFIG.trajectoriesPreviewLandSideOutline) {
                    Render3D_Shapes.OUTLINE_SIDE_QUEUE.add(
                            new Render3D_Shapes.OutlineSideAction(box, color, 2f, hit.field_178784_b));
                }
                if (CONFIG.trajectoriesPreviewLandSideFill) {
                    Render3D_Shapes.FILLED_SIDE_QUEUE.add(new Render3D_Shapes.FillSideAction(box, color, hit.field_178784_b));
                }
                break;
            }

            if (y <= -65) break;
            if (motionX == 0 && motionY == 0 && motionZ == 0) continue;

            Render3D_Shapes.drawLine(lastPos, pos, color);
        }
    }
}
