package me.Padej_.soupapi.modules;

import me.Padej_.soupapi.compat.Cameras;

import me.Padej_.soupapi.compat.Maths;

import me.Padej_.soupapi.config.ConfigurableModule;
import me.Padej_.soupapi.render.Render2D;
import me.Padej_.soupapi.utils.MathUtility;
import me.Padej_.soupapi.utils.Palette;
import me.Padej_.soupapi.utils.TexturesManager;
import me.Padej_.soupapi.event.WorldRenderContext;
import net.minecraft.block.BlockAir;
import net.minecraft.client.Minecraft;
import me.Padej_.soupapi.compat.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;
import me.Padej_.soupapi.compat.RotationAxis;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.CopyOnWriteArrayList;

public class TotemPopParticles extends ConfigurableModule {
    public static final CopyOnWriteArrayList<Particle> particles = new CopyOnWriteArrayList<>();
    private static final List<ResourceLocation> AVAILABLE_TEXTURES = new ArrayList<>();
    private static final List<Emitter> emitters = new ArrayList<>();
    private static final Random RANDOM = new Random();

    public static void onTick() {
        emitters.removeIf(Emitter::tick);
        particles.removeIf(Particle::update);
        updateAvailableTextures();
    }

    public static void onTotemPop(Entity entity) {
        if (mc.field_71439_g == null || !CONFIG.totemPopParticlesEnabled || !(entity instanceof EntityPlayer)) return;

        updateAvailableTextures();

        Color c;
        if (CONFIG.totemPopDefaultColors) {
            if (RANDOM.nextInt(4) == 0) {
                c = new Color(0.6F + RANDOM.nextFloat() * 0.2F, 0.6F + RANDOM.nextFloat() * 0.3F, RANDOM.nextFloat() * 0.2F);
            } else {
                c = new Color(0.1F + RANDOM.nextFloat() * 0.2F, 0.4F + RANDOM.nextFloat() * 0.3F, RANDOM.nextFloat() * 0.2F);
            }
        } else {
            c = Palette.getRandomColor();
        }
        emitters.add(new Emitter(entity, c));

        for (int i = 0; i < CONFIG.totemPopParticlesCount; i++) {
            particles.add(new Particle((float) entity.field_70165_t, (float) (entity.field_70163_u + entity.field_70131_O / 2), (float) entity.field_70161_v, MathUtility.random(0, 180), MathUtility.random(10f, 60f)));
        }
    }

    public static void render(WorldRenderContext context) {
        if (mc.field_71439_g != null && mc.field_71441_e != null) {
            for (Particle particle : particles) {
                particle.render(context.matrixStack(), context.tickCounter().getTickDelta(true));
            }
        }
    }

    private static void updateAvailableTextures() {
        AVAILABLE_TEXTURES.clear();

        if (CONFIG.totemPopParticlesIncludeFirefly) AVAILABLE_TEXTURES.add(TexturesManager.FIREFLY_ALT);
        if (CONFIG.totemPopParticlesIncludeDollar) AVAILABLE_TEXTURES.add(TexturesManager.DOLLAR);
        if (CONFIG.totemPopParticlesIncludeSnowflake) AVAILABLE_TEXTURES.add(TexturesManager.SNOWFLAKE);
        if (CONFIG.totemPopParticlesIncludeHeart) AVAILABLE_TEXTURES.add(TexturesManager.HEART);
        if (CONFIG.totemPopParticlesIncludeStar) AVAILABLE_TEXTURES.add(TexturesManager.STAR);
        if (CONFIG.totemPopParticlesIncludeGlyphs) AVAILABLE_TEXTURES.add(TexturesManager.getRandomGlyphParticle());

        if (AVAILABLE_TEXTURES.isEmpty()) {
            AVAILABLE_TEXTURES.add(TexturesManager.FIREFLY);
        }
    }

    public static class Particle {
        float x, y, z, px, py, pz;
        float motionX, motionY, motionZ;
        float rotationAngle, rotationSpeed;
        long time;
        Color color;
        ResourceLocation glyphTexture;

        public Particle(float x, float y, float z, float rotationAngle, float rotationSpeed) {
            int speed = CONFIG.totemPopParticlesSpeed;
            this.x = x;
            this.y = y;
            this.z = z;
            this.px = x;
            this.py = y;
            this.pz = z;
            this.motionX = MathUtility.random(-(float) speed / 50f, (float) speed / 50f);
            this.motionY = MathUtility.random(-(float) speed / 50f, (float) speed / 50f);
            this.motionZ = MathUtility.random(-(float) speed / 50f, (float) speed / 50f);
            this.time = System.currentTimeMillis();
            this.rotationAngle = rotationAngle;
            this.rotationSpeed = rotationSpeed;
            if (!AVAILABLE_TEXTURES.isEmpty()) {
                this.glyphTexture = AVAILABLE_TEXTURES.get(RANDOM.nextInt(AVAILABLE_TEXTURES.size()));
            }

            if (CONFIG.totemPopDefaultColors) {
                if (RANDOM.nextInt(4) == 0) {
                    this.color = new Color(0.6F + RANDOM.nextFloat() * 0.2F, 0.6F + RANDOM.nextFloat() * 0.3F, RANDOM.nextFloat() * 0.2F);
                } else {
                    this.color = new Color(0.1F + RANDOM.nextFloat() * 0.2F, 0.4F + RANDOM.nextFloat() * 0.3F, RANDOM.nextFloat() * 0.2F);
                }
            } else {
                this.color = Palette.getRandomColor();
            }
        }

        public boolean update() {
            double sp = Math.sqrt(motionX * motionX + motionZ * motionZ);
            px = x;
            py = y;
            pz = z;

            x += motionX;
            y += motionY;
            z += motionZ;

            if (posBlock(x, y - CONFIG.totemPopParticlesScale / 10f, z)) {
                motionY = -motionY / 1.1f;
                motionX /= 1.1f;
                motionZ /= 1.1f;
            } else if (posBlock(x - sp, y, z - sp) || posBlock(x + sp, y, z + sp) || posBlock(x + sp, y, z - sp) || posBlock(x - sp, y, z + sp) || posBlock(x + sp, y, z) || posBlock(x - sp, y, z) || posBlock(x, y, z + sp) || posBlock(x, y, z - sp)) {
                motionX = -motionX;
                motionZ = -motionZ;
            }

            if (CONFIG.totemPopParticlesPhysic.equals(TotemPopParticles.Physic.BOUNCE)) {
                motionY -= 0.035f;
            }

            motionX /= 1.005f;
            motionY /= 1.005f;
            motionZ /= 1.005f;

            return System.currentTimeMillis() - time > CONFIG.totemPopParticlesRenderTime * 1000L;
        }

        public void render(MatrixStack matrixStack, float tickDelta) {
            if (!CONFIG.totemPopParticlesEnabled) return;

            float age = (System.currentTimeMillis() - time) / (float) (CONFIG.totemPopParticlesRenderTime * 1000L);
            age = Maths.clamp(age, 0f, 1f);

            float alpha = 1f;
            float scale = CONFIG.totemPopParticlesScale;

            if (CONFIG.totemPopParticlesDisappear == TotemPopParticles.Disappear.ALPHA) {
                alpha = 1f - age;
            } else if (CONFIG.totemPopParticlesDisappear == TotemPopParticles.Disappear.SCALE) {
                scale *= (1f - age);
            }

            if (alpha <= 0f || scale <= 0f) return;

            float renderScale = 0.07f;
            double posX = Maths.lerp(tickDelta, px, x) - mc.func_175598_ae().field_78730_l;
            double posY = Maths.lerp(tickDelta, py, y) - mc.func_175598_ae().field_78731_m;
            double posZ = Maths.lerp(tickDelta, pz, z) - mc.func_175598_ae().field_78728_n;

            matrixStack.push();
            matrixStack.translate(posX, posY, posZ);
            matrixStack.scale(renderScale, renderScale, renderScale);
            matrixStack.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-Cameras.get().getYaw()));
            matrixStack.multiply(RotationAxis.POSITIVE_X.rotationDegrees(Cameras.get().getPitch()));
            matrixStack.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(rotationAngle += (1f / Minecraft.func_175610_ah()) * rotationSpeed));

            if (glyphTexture != null) {
                Render2D.drawGlyphs(matrixStack, glyphTexture, new Color(color.getRed(), color.getGreen(), color.getBlue(), (int) (alpha * 255)), scale);
            }

            matrixStack.pop();
        }

        private boolean posBlock(double x, double y, double z) {
            if (mc.field_71439_g == null || mc.field_71441_e == null) return false;
            return (!(mc.field_71441_e.func_180495_p(new BlockPos(x, y, z)).func_177230_c() instanceof BlockAir));
        }
    }

    private static class Emitter {
        final Entity entity;
        final long startTime;
        final long duration = 30L * 50L;
        final Color color;

        public Emitter(Entity entity, Color color) {
            this.entity = entity;
            this.color = color;
            this.startTime = System.currentTimeMillis();
        }

        public boolean tick() {
            if (System.currentTimeMillis() - startTime > duration) return true;

            int perTick = Math.max(1, CONFIG.totemPopParticlesCount / 30);
            for (int i = 0; i < perTick; i++) {
                particles.add(new Particle((float) entity.field_70165_t, (float) (entity.field_70163_u + entity.field_70131_O / 2f), (float) entity.field_70161_v, MathUtility.random(0, 180), MathUtility.random(10f, 60f)));
            }
            return false;
        }
    }

    public enum Physic {
        BOUNCE, FLY
    }

    public enum Disappear {
        ALPHA, SCALE
    }
}



