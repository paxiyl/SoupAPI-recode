package me.Padej_.soupapi.modules;

import me.Padej_.soupapi.compat.Cameras;

import me.Padej_.soupapi.compat.Maths;
import me.Padej_.soupapi.compat.Windows;

import me.Padej_.soupapi.config.ConfigurableModule;
import me.Padej_.soupapi.interpolation.EaseOutCirc;
import me.Padej_.soupapi.particle.Particle2D;
import me.Padej_.soupapi.reduce.ModuleSupressor;
import me.Padej_.soupapi.render.TargetHudRenderer;
import me.Padej_.soupapi.utils.EntityUtils;
import me.Padej_.soupapi.utils.MathUtility;
import me.Padej_.soupapi.utils.Palette;
import me.Padej_.soupapi.compat.DrawContext;
import net.minecraft.client.gui.GuiChat;
import me.Padej_.soupapi.compat.Camera;
import me.Padej_.soupapi.compat.RenderTickCounter;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import me.Padej_.soupapi.compat.Mat4;
import me.Padej_.soupapi.compat.Vector3f;
import me.Padej_.soupapi.compat.Vector4f;
import org.lwjgl.opengl.GL11;

import java.awt.*;
import java.util.ArrayList;
import java.util.Objects;

public class TargetHud extends ConfigurableModule {
    private static float hudScale = 0f;
    private static final float scaleSpeed = 0.2f;
    private static float hudTimer = 0f;
    public static EaseOutCirc headAnimation = new EaseOutCirc();
    public static EntityLivingBase target;
    private static EntityLivingBase lastTarget;
    private static float displayedHealth = 0f;
    private static final float healthChangeSpeed = 0.2f;
    private static final float colorAnimationSpeed = 0.01f;
    private static long lastUpdateTime = System.currentTimeMillis();
    public static float smoothedScreenX = 0f;
    public static float smoothedScreenY = 0f;
    private static final float smoothingFactor = 0.8f;

    public static final Mat4 lastProjMat = new Mat4();
    public static final Mat4 lastModMat = new Mat4();
    public static final Mat4 lastWorldSpaceMatrix = new Mat4();

    public static void onTick() {
        if (!CONFIG.targetHudEnabled) return;
        if (mc.field_71439_g == null) return;

        getTarget();

        if (lastTarget != null && !mc.field_71439_g.func_70685_l(lastTarget)) {
            hudTimer = 0;
        }

        if (target instanceof EntityPlayer) {
            if (target != lastTarget) {
                displayedHealth = Math.min(target.func_110138_aP(), getHealth());
                lastTarget = target;
            }
            hudTimer = CONFIG.targetHudRenderTime;
            target = null;
        }

        if (lastTarget instanceof EntityPlayer) {
            float targetHealth = Math.min(lastTarget.func_110138_aP(), getHealth());
            displayedHealth = Maths.lerp(healthChangeSpeed, displayedHealth, targetHealth);
        }

        if (ModuleSupressor.disableHPBar()) {
            displayedHealth = 20;
        }
    }

    public static void render(DrawContext context, RenderTickCounter renderTickCounter) {
        updateColors(TargetHudRenderer.colorAnimationProgress); // чтобы цвета всегда переливались, а не только при включенном таргет худе

        if (!CONFIG.targetHudEnabled) return;
        getTarget();

        long currentTime = System.currentTimeMillis();
        float deltaTime = (currentTime - lastUpdateTime) / 1000f;
        deltaTime = Math.min(deltaTime, 0.1f);
        lastUpdateTime = currentTime;

        float frameTime = 1.0f / 60.0f;
        float normalizedDelta = deltaTime / frameTime;

        TargetHudRenderer.colorAnimationProgress = (TargetHudRenderer.colorAnimationProgress + normalizedDelta * colorAnimationSpeed) % 1.0f;
        TargetHudRenderer.hpColorAnimationProgress = (TargetHudRenderer.hpColorAnimationProgress + normalizedDelta * colorAnimationSpeed / 2) % 1.0f;
        headAnimation.update(normalizedDelta); // Обновляем анимацию головы
        TargetHudRenderer.ticks += 0.1f * normalizedDelta; // Обновляем ticks для частиц

        // Плавная интерполяция масштаба HUD
        if (hudTimer > 0) {
            hudScale = Maths.lerp(normalizedDelta * scaleSpeed, hudScale, 1.0f);
            hudTimer -= deltaTime; // Уменьшаем таймер на основе реального времени
            if (hudTimer < 0) hudTimer = 0;
        } else {
            hudScale = Maths.lerp(normalizedDelta * scaleSpeed, hudScale, 0.0f);
        }

        // Обновляем частицы
        for (Particle2D p : new ArrayList<>(TargetHudRenderer.particles)) {
            p.updatePosition(normalizedDelta); // Передаем нормализованное время
            if (p.opacity < 1) TargetHudRenderer.particles.remove(p);
        }

        // Проверяем, существует ли lastTarget в мире
        // 1.8.9 has no getEntitiesByClass predicate query and its AxisAlignedBB.expand takes three
        // axes; checking that the entity is still in the world's entity list is both simpler
        // and exactly what the original test amounted to.
        if (lastTarget != null && (lastTarget.field_70128_L
                || mc.field_71441_e == null || !mc.field_71441_e.field_72996_f.contains(lastTarget))) {
            hudTimer = 0; // Сбрасываем таймер, чтобы HUD исчез
            lastTarget = null; // Очищаем lastTarget
        }

        if (hudScale > 0 && lastTarget instanceof EntityPlayer) {
            int targetScreenX, targetScreenY;
            // 1.8.9 has no Vec3.ZERO constant.
            Vec3 screenPos = new Vec3(0.0, 0.0, 0.0);

            // Определяем координаты HUD в зависимости от флага isFollow
            if (CONFIG.targetHudFollow) {
                // Получаем экранные координаты сущности
                float tickDelta = renderTickCounter.getTickDelta(true);
                double x = lastTarget.field_70169_q + (lastTarget.field_70165_t - lastTarget.field_70169_q) * tickDelta;
                double y = lastTarget.field_70167_r + (lastTarget.field_70163_u - lastTarget.field_70167_r) * tickDelta;
                double z = lastTarget.field_70166_s + (lastTarget.field_70161_v - lastTarget.field_70166_s) * tickDelta;
                Vec3 entityPos = new Vec3(x, y + 1.1, z);
                screenPos = worldSpaceToScreenSpace(entityPos);

                // Проверяем, находится ли сущность в видимой области
                if (screenPos.field_72449_c > 0 && screenPos.field_72449_c < 1) {
                    targetScreenX = (int) screenPos.field_72450_a;
                    targetScreenY = (int) screenPos.field_72448_b;
                } else {
                    return;
                }
            } else {
                // Используем фиксированные координаты из конфигурации
                targetScreenX = context.getScaledWindowWidth() / 2 + CONFIG.targetHudOffsetX;
                targetScreenY = context.getScaledWindowHeight() / 2 - CONFIG.targetHudOffsetY;
            }

            // Применяем сглаживание к экранным координатам
            smoothedScreenX = Maths.lerp(normalizedDelta * smoothingFactor, smoothedScreenX, targetScreenX);
            smoothedScreenY = Maths.lerp(normalizedDelta * smoothingFactor, smoothedScreenY, targetScreenY);

            context.getMatrices().push();

            // Выбор центра масштабирования в зависимости от стиля HUD
            float centerX, centerY;
            if (CONFIG.targetHudStyle.equals(Style.MINI)) {
                centerX = smoothedScreenX + 47.5f; // Центр для MiniHUD (95/2)
                centerY = smoothedScreenY + 17.5f; // (35/2)
            } else if (CONFIG.targetHudStyle.equals(Style.NORMAL)) {
                centerX = smoothedScreenX + 68.5f; // Центр для NormalHUD (137/2)
                centerY = smoothedScreenY + 23.75f; // (47.5/2)
            } else { // TINY
                centerX = smoothedScreenX;
                centerY = smoothedScreenY;
            }

            context.getMatrices().translate(centerX, centerY, 0);
            context.getMatrices().scale(hudScale, hudScale, 1f);
            context.getMatrices().translate(-centerX, -centerY, 0);

            if (CONFIG.targetHudFollow) {
                float depthFactor = Maths.clamp(1.0f - (float) screenPos.field_72449_c, 0.1f, 1.0f);
                float adjustedOffsetX = CONFIG.targetHudEntityOffsetX * 10 * depthFactor;
                float adjustedOffsetY = CONFIG.targetHudEntityOffsetY * 10 * depthFactor;
                context.getMatrices().translate(adjustedOffsetX, -adjustedOffsetY, 0);
            }

            float animationFactor = MathUtility.clamp(hudScale, 0, 1f);
            switch (CONFIG.targetHudStyle) {
                case MINI:
                    TargetHudRenderer.renderMiniHUD(context, normalizedDelta, displayedHealth, animationFactor, (EntityPlayer) lastTarget, (int) smoothedScreenX, (int) smoothedScreenY, screenPos);
                    break;
                case TINY:
                    TargetHudRenderer.renderTinyHUD(context, normalizedDelta, displayedHealth, animationFactor, (EntityPlayer) lastTarget, (int) smoothedScreenX, (int) smoothedScreenY, screenPos);
                    break;
                case ARES:
                    TargetHudRenderer.renderAresHUD(context, normalizedDelta, displayedHealth, animationFactor, (EntityPlayer) lastTarget, (int) smoothedScreenX, (int) smoothedScreenY, screenPos);
                    break;
                case ALT_1:
                    TargetHudRenderer.renderAlt_1_HUD(context, normalizedDelta, displayedHealth, animationFactor, (EntityPlayer) lastTarget, (int) smoothedScreenX, (int) smoothedScreenY, screenPos);
                    break;
                default:
                    TargetHudRenderer.renderNormalHUD(context, normalizedDelta, displayedHealth, animationFactor, (EntityPlayer) lastTarget, (int) smoothedScreenX, (int) smoothedScreenY, screenPos);
                    break;
            }

            context.getMatrices().pop();
        }
    }

    private static void updateColors(float colorAnimationProgress) {
        Color c1 = Palette.getColor(0f);   // Нижний левый
        Color c2 = Palette.getColor(0.33f); // Нижний правый
        Color c3 = Palette.getColor(0.66f); // Верхний правый
        Color c4 = Palette.getColor(1f);   // Верхний левый

        float progress = colorAnimationProgress % 1.0f;

        if (progress < 0.25f) {
            float phaseProgress = progress / 0.25f;
            TargetHudRenderer.topLeft = interpolateColor(c1, c2, phaseProgress);
            TargetHudRenderer.topRight = interpolateColor(c2, c3, phaseProgress);
            TargetHudRenderer.bottomRight = interpolateColor(c3, c4, phaseProgress);
            TargetHudRenderer.bottomLeft = interpolateColor(c4, c1, phaseProgress);
        } else if (progress < 0.5f) {
            float phaseProgress = (progress - 0.25f) / 0.25f;
            TargetHudRenderer.topLeft = interpolateColor(c2, c3, phaseProgress);
            TargetHudRenderer.topRight = interpolateColor(c3, c4, phaseProgress);
            TargetHudRenderer.bottomRight = interpolateColor(c4, c1, phaseProgress);
            TargetHudRenderer.bottomLeft = interpolateColor(c1, c2, phaseProgress);
        } else if (progress < 0.75f) {
            float phaseProgress = (progress - 0.5f) / 0.25f;
            TargetHudRenderer.topLeft = interpolateColor(c3, c4, phaseProgress);
            TargetHudRenderer.topRight = interpolateColor(c4, c1, phaseProgress);
            TargetHudRenderer.bottomRight = interpolateColor(c1, c2, phaseProgress);
            TargetHudRenderer.bottomLeft = interpolateColor(c2, c3, phaseProgress);
        } else {
            float phaseProgress = (progress - 0.75f) / 0.25f;
            TargetHudRenderer.topLeft = interpolateColor(c4, c1, phaseProgress);
            TargetHudRenderer.topRight = interpolateColor(c1, c2, phaseProgress);
            TargetHudRenderer.bottomRight = interpolateColor(c2, c3, phaseProgress);
            TargetHudRenderer.bottomLeft = interpolateColor(c3, c4, phaseProgress);
        }
    }

    public static void getTarget() {
        if (mc.field_71462_r == null) {
            if (!(EntityUtils.getTargetEntity() instanceof EntityLivingBase)) return;
            target = (EntityLivingBase) EntityUtils.getTargetEntity();
            if (target.func_82150_aj()) hudTimer = 0;
            if (target != null && !mc.field_71439_g.func_70685_l(target)) {
                target = null;
            }
        } else {
            if (mc.field_71462_r instanceof GuiChat) {
                target = mc.field_71439_g;
            } else {
                target = null;
            }
        }
    }

    public static float getHealth() {
        if (lastTarget == null) return 0f;
        if (mc.func_147114_u() != null) {
            mc.func_147104_D();
        }
        return lastTarget.func_110143_aJ() + lastTarget.func_110139_bj();
    }

    private static Color interpolateColor(Color start, Color end, float progress) {
        int r = Math.round(Maths.lerp(progress, start.getRed(), end.getRed()));
        int g = Math.round(Maths.lerp(progress, start.getGreen(), end.getGreen()));
        int b = Math.round(Maths.lerp(progress, start.getBlue(), end.getBlue()));
        int a = Math.round(Maths.lerp(progress, start.getAlpha(), end.getAlpha()));
        return new Color(r, g, b, a);
    }

    public static Vec3 worldSpaceToScreenSpace(Vec3 pos) {
        Camera camera = Cameras.get();
        int displayHeight = Windows.height();
        // LWJGL 2 reads integer state into an IntBuffer rather than an int[].
        java.nio.IntBuffer viewportBuffer = org.lwjgl.BufferUtils.createIntBuffer(16);
        GL11.glGetInteger(GL11.GL_VIEWPORT, viewportBuffer);
        int[] viewport = new int[]{
                viewportBuffer.get(0), viewportBuffer.get(1),
                viewportBuffer.get(2), viewportBuffer.get(3)};
        Vector3f target = new Vector3f();
        double scale = Windows.scaleFactor();

        double deltaX = pos.field_72450_a - camera.getPositionVector().field_72450_a;
        double deltaY = pos.field_72448_b - camera.getPositionVector().field_72448_b;
        double deltaZ = pos.field_72449_c - camera.getPositionVector().field_72449_c;

        Vector4f transformedCoordinates = new Vector4f((float) deltaX, (float) deltaY, (float) deltaZ, 1.f).mul(lastWorldSpaceMatrix);
        Mat4 matrixProj = new Mat4(lastProjMat);
        Mat4 matrixModel = new Mat4(lastModMat);
        matrixProj.mul(matrixModel).project(transformedCoordinates.x(), transformedCoordinates.y(), transformedCoordinates.z(), viewport, target);

        return new Vec3(target.x / scale, (displayHeight - target.y) / scale, target.z);
    }

    public enum Style {
        MINI, TINY, NORMAL, ARES, ALT_1
    }

    public enum Config {
        CONFIG_POS
    }
}
